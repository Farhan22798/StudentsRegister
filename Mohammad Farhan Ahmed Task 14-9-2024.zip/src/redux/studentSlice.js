import { createSlice } from "@reduxjs/toolkit";
import { addStudent, deleteStudent, getStudent, updateStudent } from "./studentActions";

const studentSlice= createSlice({
    name: "studentSlice",
    initialState: {},
    reducers: {
        invalidate: (state, { payload }) => {
            payload.forEach(item => {
                state[item] = false
            })
        }
    },
    extraReducers: builder => builder
        .addCase(addStudent.pending, (state, { payload }) => {
            state.loading = true
        })
        .addCase(addStudent.fulfilled, (state, { payload }) => {
            state.createStudent=!state.createStudent
            state.loading = false
        })
        .addCase(addStudent.rejected, (state, { payload }) => {
            state.loading = false
            state.error = payload
        })
        .addCase(getStudent.pending, (state, { payload }) => {
            state.loading = true
        })
        .addCase(getStudent.fulfilled, (state, { payload }) => {
            state.students=payload
            state.loading = false
        })
        .addCase(getStudent.rejected, (state, { payload }) => {
            state.loading = false
            state.error = payload
        })
        .addCase(updateStudent.pending, (state, { payload }) => {
            state.loading = true
        })
        .addCase(updateStudent.fulfilled, (state, { payload }) => {
            state.studentUpdate=!state.studentUpdate
            state.loading = false
        })
        .addCase(updateStudent.rejected, (state, { payload }) => {
            state.loading = false
            state.error = payload
        })
        .addCase(deleteStudent.pending, (state, { payload }) => {
            state.loading = true
        })
        .addCase(deleteStudent.fulfilled, (state, { payload }) => {
            state.studentDelete=!state.studentDelete
            state.loading = false
        })
        .addCase(deleteStudent.rejected, (state, { payload }) => {
            state.loading = false
            state.error = payload
        })
       
})

export const { invalidate } = studentSlice.actions
export default studentSlice.reducer