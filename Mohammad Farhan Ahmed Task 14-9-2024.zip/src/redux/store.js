import { configureStore } from "@reduxjs/toolkit";
import studentSlice from "./studentSlice";


const reduxStore = configureStore({
    reducer: {
        allStudents: studentSlice,
    },
})

export default reduxStore